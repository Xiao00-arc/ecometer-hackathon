package com.example.ecometer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcometerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcometerApplication.class, args);
	}

}
